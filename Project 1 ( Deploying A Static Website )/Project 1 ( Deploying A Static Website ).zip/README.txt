S3-Bucket-Name: project1-static-website-deployment

URL: http://d3f06pddhecq2s.cloudfront.net/index.html